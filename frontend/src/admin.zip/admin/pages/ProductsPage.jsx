import { useEffect, useState } from 'react';
import AdminModal from '../components/AdminModal';
import { getActiveCategories } from '../services/categoriesService';

const emptyProduct = {
  name: '',
  eyebrow: 'Premium collection',
  category: '',
  description: '',
  warranty: '10 years',
  firmness: 'Medium firm',
  materials: '',
  price4: '',
  price5: '',
  price6: '',
  price8: '',
  badge: 'New arrival',
  image: '',
};
const toFormProduct = (product) => {
  if (!product) return emptyProduct;
  return {
    ...emptyProduct,
    ...product,
    materials: Array.isArray(product.materials)
      ? product.materials.join(', ')
      : product.materials || '',
    price4: product.prices?.[4] || '',
    price5: product.prices?.[5] || '',
    price6: product.prices?.[6] || '',
    price8: product.prices?.[8] || '',
  };
};

function ProductForm({ product, onSave, onClose }) {
  const [draft, setDraft] = useState(toFormProduct(product));
  const [categories, setCategories] = useState([]);

  useEffect(() => setDraft(toFormProduct(product)), [product]);
  useEffect(() => setCategories(getActiveCategories()), []);

  const setValue = (event) =>
    setDraft((current) => ({ ...current, [event.target.name]: event.target.value }));
  const uploadImage = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setDraft((current) => ({ ...current, image: reader.result }));
    reader.readAsDataURL(file);
  };
  const submit = (event) => {
    event.preventDefault();
    const prices = Object.fromEntries(
      [4, 5, 6, 8]
        .filter((size) => Number(draft[`price${size}`]) > 0)
        .map((size) => [size, Number(draft[`price${size}`])])
    );
    if (!draft.image) {
      alert('Please upload a product image.');
      return;
    }
    if (!draft.category) {
      alert('Please select a category.');
      return;
    }
    if (!Object.keys(prices).length) {
      alert('Add at least one thickness price.');
      return;
    }
    onSave({
      ...draft,
      id:
        product?.id ||
        draft.name
          .toLowerCase()
          .trim()
          .replace(/[^a-z0-9]+/g, '-'),
      materials: draft.materials
        .split(',')
        .map((material) => material.trim())
        .filter(Boolean),
      prices,
    });
  };
  return (
    <form className="product-form" onSubmit={submit}>
      <div className="product-form-section image-upload">
        <div>
          {draft.image ? (
            <img src={draft.image} alt="Product preview" />
          ) : (
            <span>Product image preview</span>
          )}
        </div>
        <label className="upload-control">
          Upload product image
          <input type="file" accept="image/*" onChange={uploadImage} />
          <small>JPG, PNG or WEBP · recommended 1200 × 900 px</small>
        </label>
      </div>
      <div className="product-form-section">
        <h3>Product details</h3>
        <div className="form-two-columns">
          <label>
            Product name
            <input
              required
              autoFocus
              name="name"
              value={draft.name}
              onChange={setValue}
              placeholder="e.g. OG-Ortho Luxe"
            />
          </label>
          <label>
            Collection / eyebrow
            <input
              required
              name="eyebrow"
              value={draft.eyebrow}
              onChange={setValue}
              placeholder="e.g. Signature collection"
            />
          </label>
        </div>
        <div className="form-two-columns" style={{ marginBottom: '12px' }}>
          <label>
            Category
            <select name="category" value={draft.category} onChange={setValue} required>
              <option value="" disabled>
                Select a category
              </option>
              {categories.map((c) => (
                <option key={c.id} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </label>
        </div>
        <label>
          Short description
          <textarea
            required
            name="description"
            rows="4"
            value={draft.description}
            onChange={setValue}
            placeholder="Describe the comfort, support and ideal sleeper."
          />
        </label>
        <div className="form-three-columns">
          <label>
            Warranty
            <input
              required
              name="warranty"
              value={draft.warranty}
              onChange={setValue}
              placeholder="10 years"
            />
          </label>
          <label>
            Firmness
            <input
              required
              name="firmness"
              value={draft.firmness}
              onChange={setValue}
              placeholder="Medium firm"
            />
          </label>
          <label>
            Badge
            <input name="badge" value={draft.badge} onChange={setValue} placeholder="Best seller" />
          </label>
        </div>
        <label>
          Materials <small>Separate each material with a comma</small>
          <input
            required
            name="materials"
            value={draft.materials}
            onChange={setValue}
            placeholder="Knitted fabric, Memory foam, HR foam"
          />
        </label>
      </div>
      <div className="product-form-section">
        <h3>
          Pricing by thickness <small>Price per square foot (₹)</small>
        </h3>
        <div className="form-four-columns">
          {[4, 5, 6, 8].map((size) => (
            <label key={size}>
              {size} inch
              <input
                name={`price${size}`}
                type="number"
                min="1"
                value={draft[`price${size}`]}
                onChange={setValue}
                placeholder="0"
              />
            </label>
          ))}
        </div>
      </div>
      <div className="product-form-actions">
        <button type="button" onClick={onClose}>
          Cancel
        </button>
        <button className="admin-action">Save product</button>
      </div>
    </form>
  );
}

export default function ProductsPage({ products, onAdd, onUpdate, onDelete }) {
  const [editingProduct, setEditingProduct] = useState(null);
  const [isOpen, setIsOpen] = useState(false);
  const close = () => {
    setIsOpen(false);
    setEditingProduct(null);
  };
  const save = (product) => {
    if (editingProduct) onUpdate(product);
    else onAdd(product);
    close();
  };
  return (
    <>
      <div className="admin-title">
        <div>
          <p>Catalog</p>
          <h1>Products</h1>
        </div>
        <button className="admin-action" onClick={() => setIsOpen(true)}>
          + Add product
        </button>
      </div>
      <section className="admin-card product-admin">
        {products.map((product) => (
          <div className="admin-product" key={product.id}>
            <img src={product.image} alt="" />
            <span>
              <b>{product.name}</b>
              <small>
                {product.category && <strong>{product.category} · </strong>}
                {product.eyebrow} · {product.firmness} · {product.warranty} warranty
              </small>
              <small className="product-description-preview">{product.description}</small>
            </span>
            <strong>₹{Math.min(...Object.values(product.prices))}/sq.ft</strong>
            <button
              className="edit-product"
              onClick={() => {
                setEditingProduct(product);
                setIsOpen(true);
              }}
            >
              Edit
            </button>
            <button onClick={() => onDelete(product.id)}>Delete</button>
          </div>
        ))}
      </section>
      {isOpen && (
        <AdminModal
          title={editingProduct ? `Edit ${editingProduct.name}` : 'Add a new product'}
          onClose={close}
        >
          <ProductForm product={editingProduct} onSave={save} onClose={close} />
        </AdminModal>
      )}
    </>
  );
}
