import { useEffect, useState } from 'react';
import AdminModal from '../components/AdminModal';
import { getCategories, addCategory, updateCategory, deleteCategory } from '../services/categoriesService';

function CategoryForm({ category, onSave, onClose }) {
  const [draft, setDraft] = useState({
    name: category?.name || '',
    description: category?.description || '',
    status: category?.status || 'ACTIVE'
  });

  useEffect(() => {
    setDraft({
      name: category?.name || '',
      description: category?.description || '',
      status: category?.status || 'ACTIVE'
    });
  }, [category]);

  const setValue = (event) => setDraft(current => ({ ...current, [event.target.name]: event.target.value }));

  const submit = (event) => {
    event.preventDefault();
    if (!draft.name.trim()) {
      alert('Category name is required.');
      return;
    }
    onSave(draft);
  };

  return (
    <form className="admin-form-stack" onSubmit={submit}>
      <label>Category Name
        <input name="name" value={draft.name} onChange={setValue} placeholder="e.g., Mattresses" required />
      </label>
      <label>Description (Optional)
        <input name="description" value={draft.description} onChange={setValue} placeholder="Brief description of the category" />
      </label>
      <label>Status
        <select name="status" value={draft.status} onChange={setValue}>
          <option value="ACTIVE">Active</option>
          <option value="INACTIVE">Inactive</option>
        </select>
      </label>
      <div className="product-form-actions" style={{ marginTop: '20px' }}>
        <button type="button" onClick={onClose}>Cancel</button>
        <button type="submit" className="admin-action">Save Category</button>
      </div>
    </form>
  );
}

export default function CategoriesPage() {
  const [categories, setCategories] = useState([]);
  const [editingCategory, setEditingCategory] = useState(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [search, setSearch] = useState('');

  useEffect(() => {
    setCategories(getCategories());
  }, []);

  const openAddForm = () => {
    setEditingCategory(null);
    setIsFormOpen(true);
  };

  const openEditForm = (category) => {
    setEditingCategory(category);
    setIsFormOpen(true);
  };

  const closeForm = () => {
    setIsFormOpen(false);
    setEditingCategory(null);
  };

  const handleSave = (categoryData) => {
    try {
      if (editingCategory) {
        updateCategory(editingCategory.id, categoryData);
      } else {
        addCategory(categoryData);
      }
      setCategories(getCategories());
      closeForm();
    } catch (error) {
      alert(error.message);
    }
  };

  const handleDelete = (id) => {
    if (confirm('Are you sure you want to delete this category?')) {
      deleteCategory(id);
      setCategories(getCategories());
    }
  };

  const handleStatusToggle = (id, currentStatus) => {
    updateCategory(id, { status: currentStatus === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE' });
    setCategories(getCategories());
  };

  const filteredCategories = categories.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <section>
      <div className="admin-title">
        <div>
          <p>Taxonomy</p>
          <h1>Categories</h1>
        </div>
        <button className="admin-action" onClick={openAddForm}>+ Add Category</button>
      </div>

      <div className="admin-card">
        <div className="order-toolbar">
          <input 
            type="search" 
            placeholder="Search categories..." 
            value={search} 
            onChange={e => setSearch(e.target.value)} 
          />
        </div>

        <div className="order-table">
          <header className="table-head" style={{ gridTemplateColumns: '2fr 3fr 1fr 1fr 1fr' }}>
            <span>Category Name</span>
            <span>Description</span>
            <span>Status</span>
            <span>Created Date</span>
            <span style={{ textAlign: 'right' }}>Actions</span>
          </header>
          {filteredCategories.length === 0 ? (
            <div className="module-empty" style={{ gridColumn: '1/-1' }}>
              <span>📁</span>
              <h2>No categories found</h2>
              <p>Get started by creating your first product category.</p>
              <button onClick={openAddForm}>Add category</button>
            </div>
          ) : (
            filteredCategories.map(category => (
              <article key={category.id} className="table-row" style={{ gridTemplateColumns: '2fr 3fr 1fr 1fr 1fr' }}>
                <b>{category.name}</b>
                <span className="product-description-preview">{category.description || '-'}</span>
                <div>
                  <span className={`order-status ${category.status === 'ACTIVE' ? 'status-delivered' : 'status-cancelled'}`}>
                    {category.status}
                  </span>
                </div>
                <span>{new Date(category.createdAt).toLocaleDateString()}</span>
                <div className="row-actions" style={{ justifyContent: 'flex-end' }}>
                  <button onClick={() => handleStatusToggle(category.id, category.status)} title={category.status === 'ACTIVE' ? 'Disable' : 'Enable'}>
                    {category.status === 'ACTIVE' ? '⏸' : '▶'}
                  </button>
                  <button onClick={() => openEditForm(category)} title="Edit">✎</button>
                  <button onClick={() => handleDelete(category.id)} title="Delete" style={{ color: '#b53d3d' }}>✕</button>
                </div>
              </article>
            ))
          )}
        </div>
      </div>

      {isFormOpen && (
        <AdminModal title={editingCategory ? 'Edit Category' : 'Add Category'} onClose={closeForm}>
          <CategoryForm category={editingCategory} onSave={handleSave} onClose={closeForm} />
        </AdminModal>
      )}
    </section>
  );
}
